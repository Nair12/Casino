﻿namespace Casino.Models
{
	public class History
	{
		public int Id { get; set; }	

		public int Number {  get; set; }

		public string Color { get; set; }

		public DateTime createdAt { get; set; }

	}
}
